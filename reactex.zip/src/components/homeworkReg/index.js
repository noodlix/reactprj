import Registration from "./Registration";

export {Registration};