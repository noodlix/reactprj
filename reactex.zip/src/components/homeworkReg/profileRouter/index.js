import ProfileRouter from "./ProfileRouter";

export default ProfileRouter;