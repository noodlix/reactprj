import UsersPage from "./UsersPage";

export default UsersPage;