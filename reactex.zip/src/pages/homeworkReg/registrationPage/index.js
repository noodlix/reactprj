import RegistrationPage from './RegistrationPage';

export default RegistrationPage;