import React from 'react'
import Registration from '../../../components/homeworkReg/Registration'

const RegistrationPage = () => {
  return (
    <div className="registration">
      <Registration />
    </div>
  )
}

export default RegistrationPage;