import ProfilePage from "./ProfilePage";

export default ProfilePage;