import OnePostPage from "./OnePostPage";

export default OnePostPage;