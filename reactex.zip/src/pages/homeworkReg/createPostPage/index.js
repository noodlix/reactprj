import CreatePostPage from "./CreatePostPage";

export default CreatePostPage;