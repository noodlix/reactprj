import UserPage from "./UserPage";

export default UserPage;