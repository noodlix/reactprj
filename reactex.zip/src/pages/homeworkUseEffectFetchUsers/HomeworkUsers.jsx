import React from 'react';

import {Stand} from '../../components/homeworkUseEffect'

const HomeworkUsers = () => {
    return (
        <Stand />
    )
}

export default HomeworkUsers;